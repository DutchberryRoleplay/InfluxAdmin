---
name: Request a feature
about: Suggest an idea for a new feature, or a way to improve an existing Adonis feature.
title: ''
labels: "✨ enhancement"
assignees: ''

---

- Is your feature request related to a problem? If so, please describe concisely. (Eg. "I'm always frustrated when [...]", "It's currently too difficult to [...]")
- What is the solution, improvement or enhancement you'd like to see? Please describe.
- (Any additional context.)
