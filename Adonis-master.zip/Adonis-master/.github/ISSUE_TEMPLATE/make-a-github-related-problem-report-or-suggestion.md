---
name: Make a GitHub-related problem report or suggestion
about: For all things pertaining to documentation, the README file, the User Manual,
  GitHub workflows etc.
title: ''
labels: github
assignees: ''

---

[Type your report or suggestion here. If applicable, please include the link to the page that needs to be fixed/improved]
