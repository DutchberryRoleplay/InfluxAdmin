return {
	equalObjects = require(script.equalObjects),
	func = require(script.func),
	isEmpty = require(script.isEmpty),
}
