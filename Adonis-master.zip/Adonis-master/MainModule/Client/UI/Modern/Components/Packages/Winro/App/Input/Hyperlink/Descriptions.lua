return {
	Rest = {
		Name = 'Rest',
		Text = 'colors/Fill_Color/Accent_Text/Primary',
	},
	Hover = {
		Name = 'Hover',
		Text = 'colors/Fill_Color/Accent_Text/Secondary',
	},
	Pressed = {
		Name = 'Pressed',
		Text = 'colors/Fill_Color/Accent_Text/Tertiary',
	},
	Disabled = {
		Name = 'Disabled',
		Text = 'colors/Fill_Color/Accent_Text/Disabled',
	},
}