return require(script.Parent._Index["roblox_roact@1.4.4"]["roact"])
