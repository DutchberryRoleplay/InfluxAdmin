return require(script.Parent._Index["sleitnick_signal@1.2.1"]["signal"])
