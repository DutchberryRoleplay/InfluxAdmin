return require(script.Parent._Index["csqrl_sift@0.0.3"]["sift"])
