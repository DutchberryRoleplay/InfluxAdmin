local Symbol = require(script.Parent.Parent.Symbol)

local Children = Symbol.named("Children")

return Children
