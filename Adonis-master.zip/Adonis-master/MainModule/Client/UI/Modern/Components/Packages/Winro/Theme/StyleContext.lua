local Theme = script.Parent
local Winro = Theme.Parent
local Roact = require(Winro.parent.Roact)

return Roact.createContext(nil)
