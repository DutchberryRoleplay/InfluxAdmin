local hum = script.Parent:FindFirstChildOfClass("Humanoid")

while true do
	hum.Jump = true
	task.wait()
end
