while true do
	script.Parent.Texture = "rbxassetid://185945467"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945486"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945493"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945515"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945527"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945553"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945573"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945586"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945612"
	task.wait(.1)
	script.Parent.Texture = "rbxassetid://185945634"
	task.wait(.1)
end
