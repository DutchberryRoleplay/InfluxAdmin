while true do
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747849"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747854"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747863"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747870"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747877"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747879"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747885"
	task.wait(0.05)
	script.Parent.Texture = "http://www.roblox.com/asset/?id=183747890"
	task.wait(0.05)
end
