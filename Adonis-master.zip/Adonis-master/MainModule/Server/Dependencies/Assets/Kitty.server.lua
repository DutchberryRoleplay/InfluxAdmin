while true do
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224764"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224790"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224800"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224820"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224830"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224844"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224861"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224899"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224924"
  wait(0.1)
  script.Parent.Texture = "http://www.roblox.com/asset/?id=280224955"
  wait(0.1)
end