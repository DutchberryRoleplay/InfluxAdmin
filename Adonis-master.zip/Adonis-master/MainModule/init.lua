-----------------------
-- Adonis MainModule --
-----------------------

--[[
	Follow development on our GitHub: https://github.com/Epix-Incorporated/Adonis/
	Distributed under the MIT license.

	Please do not redistribute without proper credits.
--]]

--// Load server
return require(script.Server.Server)
